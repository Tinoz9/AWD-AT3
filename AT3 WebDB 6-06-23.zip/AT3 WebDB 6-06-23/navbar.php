<nav class="navbar navbar-expand-lg navbar-light text-light bg-primary"> 
    <div class="container-fluid" >
        <a href="https://192.168.56.93/AWD AT3/Index.php" class="navbar-brand">Index</a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div text-light class="navbar-nav" >
                <a href="https://192.168.56.93/AWD AT3/Contact.php" class="nav-item nav-link active">Contact</a>
                <a href="https://192.168.56.93/AWD AT3/Group-1-Questions.php" class="nav-item nav-link">Question 1</a>
                <a href="https://192.168.56.93/AWD AT3/Group-2-Questions.php" class="nav-item nav-link">Question 2</a>
                <a href="https://192.168.56.93/AWD AT3/Group-3-Questions.php" class="nav-item nav-link">Question 3</a>
				<a href="https://192.168.56.93/AWD AT3/Group-4-Questions.php" class="nav-item nav-link">Question 4</a>
                <a href="https://192.168.56.93/AWD AT3/Group-5-Questions.php" class="nav-item nav-link">Question 5</a>
                <a href="https://192.168.56.93/AWD AT3/Group-6-Questions.php" class="nav-item nav-link">Question 6</a>
                <a href="https://192.168.56.93/AWD AT3/Group-7-Questions.php" class="nav-item nav-link">Question 7</a>
                <a href="https://192.168.56.93/AWD AT3/Group-8-Questions.php" class="nav-item nav-link">Question 8</a>
                <a href="https://192.168.56.93/AWD AT3/Group-9-Questions.php" class="nav-item nav-link">Question 9</a>
            </div>
        </div>
    </div>
</nav>